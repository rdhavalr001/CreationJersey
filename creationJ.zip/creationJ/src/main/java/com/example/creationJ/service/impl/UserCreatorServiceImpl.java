/**
 * 
 */
package com.example.creationJ.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.creationJ.dao.UserCreatorDao;
import com.example.creationJ.model.User;
import com.example.creationJ.service.UserCreatorService;

/**
 * @author dradadiy
 *
 */
@Service("UserCreatorServiceImpl")
@Transactional
public class UserCreatorServiceImpl implements UserCreatorService {
	
	@Autowired
	private UserCreatorDao userCreatorDao;
	
	@Transactional
	@Override
	public boolean createUser(User user) {
		
		return userCreatorDao.createUser(user);
	}


	public UserCreatorDao getUserCreatorDao() {
		return userCreatorDao;
	}


	public void setUserCreatorDao(UserCreatorDao userCreatorDao) {
		this.userCreatorDao = userCreatorDao;
	}
}
