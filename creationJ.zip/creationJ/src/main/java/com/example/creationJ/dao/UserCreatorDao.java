/**
 * 
 */
package com.example.creationJ.dao;

import com.example.creationJ.model.User;

/**
 * @author dradadiy
 *
 */

public interface UserCreatorDao {
	public boolean createUser(User user);
}
