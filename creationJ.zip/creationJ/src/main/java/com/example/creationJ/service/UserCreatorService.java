/**
 * 
 */
package com.example.creationJ.service;

import com.example.creationJ.model.User;

/**
 * @author dradadiy
 *
 */
public interface UserCreatorService {
	public boolean createUser(User user);
}
