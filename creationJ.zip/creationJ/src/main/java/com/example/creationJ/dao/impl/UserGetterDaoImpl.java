/**
 * 
 */
package com.example.creationJ.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.creationJ.dao.UserGetterDao;
import com.example.creationJ.model.User;

/**
 * @author dradadiy
 *
 */
@SuppressWarnings("unchecked")
@Repository("userGetterDaoImpl")
public class UserGetterDaoImpl implements UserGetterDao {
	@Transactional
    public EntityManager getEntityManager() {
		return entityManager;
	}

    @PersistenceContext 
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	private EntityManager entityManager;
	
	@Transactional
	private Session getCurrentSession() {
		return entityManager.unwrap(Session.class);
	}
	
	
	@Override
	public List<User> getAllUsers() {
		Session session = getCurrentSession();
		Query<User> query = session.createQuery("from User");
		return query.list();
		
	}
	
	@Override
	public User getUserWithField(User user){
		if(user != null) {
			if(user.getUsername() != null && user.getUsername() != "") {
				return getUserWithUsername(user);
			}else if(user.getContactNo() != null && user.getContactNo() != "") {
				return getUserWithContact(user);
			}else if(user.getEmail() != null && user.getEmail() != "") {
				return getUserWithEmail(user);
			}
		}
		return null;
		
		
	}
	
	@Override
	public User getUserWithUsername(User user) {
		Session session = getCurrentSession();
		/*CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<User> cQuery = builder.createQuery(User.class);
		Root<User> root = cQuery.from(User.class);
		cQuery.select(root).where(builder.equal(root.get("username"), user.getUsername()));
		Query<User> q = session.createQuery(cQuery);
		return q.getResultList().get(0);*/
		
		Query<User> query = session.createQuery("from User where username= :username");
		query.setParameter("username", user.getUsername());
		try {
			return query.getSingleResult();
		}catch(NoResultException e) {
			System.out.println("No Result Found exception for username: "+user.getUsername());
		}
		return null;
		
	}

	@Override
	public User getUserWithContact(User user) {
		Session session = getCurrentSession();
		/*CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<User> cQuery = builder.createQuery(User.class);
		Root<User> root = cQuery.from(User.class);
		cQuery.select(root).where(builder.equal(root.get("contactNo"), user.getContactNo()));
		Query<User> q = session.createQuery(cQuery);
		return q.getResultList().get(0);*/
		
		Query<User> query = session.createQuery("from User where contact_no= :contact_no");
		query.setParameter("contact_no", user.getContactNo());
		try {
			return query.getSingleResult();
		}catch(NoResultException e) {
			System.out.println("No Result Found exception for Contact No: "+user.getContactNo());
		}
		return null;
	}

	@Override
	public User getUserWithEmail(User user) {
		Session session = getCurrentSession();
		/*CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<User> cQuery = builder.createQuery(User.class);
		Root<User> root = cQuery.from(User.class);
		cQuery.select(root).where(builder.equal(root.get("email"), user.getEmail()));;
		Query<User> q = session.createQuery(cQuery);
		return q.getSingleResult();
		*/
		Query<User> query = session.createQuery("from User where email= :email");
		query.setParameter("email", user.getEmail());
		try {
			return query.getSingleResult();
		}catch(NoResultException e) {
			System.out.println("No Result Found exception for Email: "+user.getEmail());
		}
		return null;
	}

	@Override
	public List<User> getUserWithCity(User user) {
		//List<Object> users = new ArrayList<>();
		Session session = getCurrentSession();
		/*CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<User> cQuery = builder.createQuery(User.class);
		Root<User> root = cQuery.from(User.class);
		cQuery.select(root).where(builder.equal(root.get("city"), user.getCity()));
		Query<User> q = session.createQuery(cQuery);
		return q.getResultList();*/
		/*@SuppressWarnings({ "deprecation", "rawtypes" })
		Query qry = session.createSQLQuery(q.getQueryString());
		users = qry.list();
		users.forEach(i -> System.out.println(i));
		return qry.list();*/
		Query<User> query = session.createQuery("from User where city= :city");
		query.setParameter("city", user.getCity());
		return query.list();
	}

	@Override
	public List<User> getUserWithFirstName(User user) {
		Session session = getCurrentSession();
		/*CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<User> cQuery = builder.createQuery(User.class);
		Root<User> root = cQuery.from(User.class);
		cQuery.select(root).where(builder.equal(root.get("firstName"), user.getFirstName()));
		Query<User> q = session.createQuery(cQuery);
		return q.getResultList();*/
		Query<User> query = session.createQuery("from User where firstName= :firstName");
		query.setParameter("firstName", user.getFirstName());
		return query.list();
	}

	@Override
	public List<User> getUserWithLastName(User user) {
		Session session = getCurrentSession();
		/*CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<User> cQuery = builder.createQuery(User.class);
		Root<User> root = cQuery.from(User.class);
		cQuery.select(root).where(builder.equal(root.get("lastName"), user.getLastName()));
		Query<User> q = session.createQuery(cQuery);
		return q.getResultList();*/
		Query<User> query = session.createQuery("from User where lastName= :lastName");
		query.setParameter("lastName", user.getLastName());
		return query.list();
	}
	

}
