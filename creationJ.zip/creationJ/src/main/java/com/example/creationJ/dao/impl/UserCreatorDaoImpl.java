/**
 * 
 */
package com.example.creationJ.dao.impl;

import java.util.List;
import java.util.ListIterator;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.creationJ.dao.UserCreatorDao;
import com.example.creationJ.dao.UserGetterDao;
import com.example.creationJ.model.User;

/**
 * @author dradadiy
 *
 */
@Repository("UserCreatorDaoImpl")
public class UserCreatorDaoImpl implements UserCreatorDao {

	
	@PersistenceContext
    private EntityManager entityManager;
	
	private Session getCurrentSession() {
		return entityManager.unwrap(Session.class);
	}
	
	@Autowired
	private UserGetterDao userGetterDao;
	
	@SuppressWarnings("unused")
	@Override
	public boolean createUser(User user) {
		Session session = getCurrentSession();
		User u= userGetterDao.getUserWithField(user);
		
		if(u != null && (u.getUsername()!=null && u.getUsername().equals(user.getUsername()) ||
						(u.getContactNo()!=null && u.getContactNo().equals(user.getContactNo()) ||
						(u.getEmail()!=null && u.getEmail().equals(user.getEmail())
						)))) {
			
			BeanUtils.copyProperties(user, u, "id","username");
			
			session.saveOrUpdate(u);
		}else session.save(user);	
		
		return true;
	}

	public UserGetterDao getUserGetterDao() {
		return userGetterDao;
	}

	public void setUserGetterDao(UserGetterDao userGetterDao) {
		this.userGetterDao = userGetterDao;
	}


	

}
