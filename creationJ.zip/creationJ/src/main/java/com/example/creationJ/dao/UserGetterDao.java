/**
 * 
 */
package com.example.creationJ.dao;

import java.util.List;

import com.example.creationJ.model.User;

/**
 * @author dradadiy
 *
 */
public interface UserGetterDao {
	public User getUserWithUsername(User user);
	public User getUserWithContact(User user);
	public User getUserWithEmail(User user);
	public List<User> getUserWithCity(User user);
	public List<User> getUserWithFirstName(User user);
	public List<User> getUserWithLastName(User user);
	public List<User> getAllUsers();
	public User getUserWithField(User user);

}
