package com.example.creationJ.controller;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.creationJ.model.User;
import com.example.creationJ.service.UserCreatorService;
import com.example.creationJ.service.UserGetterService;

@Controller
@Path("/")
public class DefaultController {

	@Autowired
	private UserCreatorService userCreatorService;
	
	@Autowired
	private UserGetterService userGetterService;
	
	@GET
	@Produces("application/text")
	public String open() {
	 return "How are You?";	
	}
	
	@Path("/submit")
	@POST
	@Produces("application/json")
	public Boolean createUser(@RequestBody User user) {
		if(userCreatorService.createUser(user)) return true;
		else
		return false;
	}

	@POST
	@Path("/search")
	@Produces("application/json")
    @Consumes("application/json")
	public List<User> searchUser(@RequestBody User user) {
		
		return userGetterService.searchUser(user);
	}
	
	@GET
	@Path("/get/users")
	@Produces("application/json")
	//@Produces("application/xml")
	public List<User> searchUser() {
		return userGetterService.getAllUsers();
	}
	
	/*@RequestMapping(value= "/retrieve/username", method = RequestMethod.POST)
	public List<User> getUserWithUsername(@RequestBody User user) {
		System.out.println(user);
		return userGetterService.getUserWithUsername(user);
	}
	
	@RequestMapping(value= "/retrieve/contact", method = RequestMethod.POST)
	public List<User> getUserWithContact(@RequestBody User user) {
		System.out.println(user);
		return userGetterService.getUserWithContact(user);
	}
	
	@RequestMapping(value= "/retrieve/email", method = RequestMethod.POST)
	public List<User> getUserWithEmail(@RequestBody User user) {
		System.out.println(user);
		return userGetterService.getUserWithEmail(user);
	}
	
	@RequestMapping(value= "/retrieve/city", method = RequestMethod.POST)
	public List<User> getUserWithCity(@RequestBody User user){
		System.out.println(user);
		return userGetterService.getUserWithCity(user);
	}
	
	@RequestMapping(value= "/retrieve/firstname", method = RequestMethod.POST)
	public List<User> getUserWithFirstName(@RequestBody User user){
		System.out.println(user);
		return userGetterService.getUserWithFirstName(user);
	}
	
	@RequestMapping(value= "/retrieve/lastname", method = RequestMethod.POST)
	public List<User> getUserWithLastName(User user){
		System.out.println(user);
		return userGetterService.getUserWithLastName(user);
	}*/

	public UserCreatorService getUserCreatorService() {
		
		return userCreatorService;
	}

	public void setUserCreatorService(UserCreatorService userCreatorService) {
		this.userCreatorService = userCreatorService;
	}

	public UserGetterService getUserGetterService() {
		return userGetterService;
	}

	public void setUserGetterService(UserGetterService userGetterService) {
		this.userGetterService = userGetterService;
	}
	
}
