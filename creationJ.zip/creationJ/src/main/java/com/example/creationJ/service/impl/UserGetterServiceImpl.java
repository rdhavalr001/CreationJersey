/**
 * 
 */
package com.example.creationJ.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.creationJ.dao.UserGetterDao;
import com.example.creationJ.model.User;
import com.example.creationJ.service.UserGetterService;

/**
 * @author dradadiy
 *
 */
@Service("UserGetterServiceImpl")
public class UserGetterServiceImpl implements UserGetterService {

	@Autowired
	private UserGetterDao userGetterDao; 
	
	@Override
	public List<User> searchUser(User user) {
		if(user != null) {
			if(user.getUsername() != null) return Arrays.asList(getUserWithUsername(user));
			if(user.getFirstName() != null) return getUserWithFirstName(user); 
			if(user.getLastName() != null) return getUserWithLastName(user); 
			if(user.getContactNo() != null) return Arrays.asList(getUserWithContact(user)); 
			if(user.getEmail() != null) return Arrays.asList(getUserWithEmail(user)); 
			if(user.getCity() != null) return getUserWithCity(user); 
			else return null;	
		}else return null;	
	}
	
	@Transactional
	@Override
	public List<User> getAllUsers() {
		return userGetterDao.getAllUsers();
	}
	
	@Transactional
	@Override
	public User getUserWithUsername(User user) {
		return userGetterDao.getUserWithUsername(user);
	}
	
	@Transactional
	@Override
	public User getUserWithContact(User user) {
		return userGetterDao.getUserWithContact(user);
	}
	
	@Transactional
	@Override
	public User getUserWithEmail(User user) {
		return userGetterDao.getUserWithEmail(user);
	}

	@Transactional
	@Override
	public List<User> getUserWithCity(User user) {
		return userGetterDao.getUserWithCity(user);
	}
	
	@Transactional
	@Override
	public List<User> getUserWithFirstName(User user) {
		return userGetterDao.getUserWithFirstName(user);
	}

	@Transactional
	@Override
	public List<User> getUserWithLastName(User user) {
		return userGetterDao.getUserWithLastName(user);
	}

	public UserGetterDao getUserGetterDao() {
		return userGetterDao;
	}

	public void setUserGetterDao(UserGetterDao userGetterDao) {
		this.userGetterDao = userGetterDao;
	}

	

	

}
