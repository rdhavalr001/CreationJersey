package com.example.creation;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.example.creation.controller.DefaultController;
import com.example.creation.model.User;
import com.example.creation.service.UserCreatorService;
import com.example.creation.service.UserGetterService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = DefaultController.class, secure = false)
public class CreationApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private UserCreatorService userCreatorService;

	@MockBean
	private UserGetterService userGetterService;

	User mockUser = new User("davidred1", "David1", "Red", "7401213182", "rdavidr02@gamil.com", "pune", "David123");
	List<User> mockList = new ArrayList<>();

	String userJson = "{\"username\": \"davidred1\",\"firstName\": \"David1\",\"lastName\": \"Red\",\"contactNo\": \"7401213182\",\"email\": \"rdavidr02@gamil.com\",\"city\": \"pune\",\"password\": \"David123\"}";
	/*
	 * @Test public void openAppTest() throws Exception { RequestBuilder
	 * requestBuilder = MockMvcRequestBuilders.get(
	 * "/open").accept(MediaType.TEXT_HTML); MvcResult result =
	 * mockMvc.perform(requestBuilder).andReturn();
	 * System.out.println(result.getResponse()); String expected = "How are You?";
	 * JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(),
	 * false);
	 * 
	 * }
	 */

	@Test
	public void createUserTest() throws Exception {
		//mockList.add(mockUser);


		Mockito.when(userCreatorService.createUser(mockUser)).thenReturn(true);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/submit").accept(MediaType.APPLICATION_JSON)
				.content(userJson).contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		MockHttpServletResponse response = result.getResponse();

		assertEquals(HttpStatus.CREATED.value(), response.getStatus());
		System.out.println(response.getHeader(HttpHeaders.LOCATION));
		assertEquals("http://localhost:8090/submit", response.getHeader(HttpHeaders.LOCATION));

	}

	@Test
	public void retrieveUserTest() throws Exception {

		//mockList.add(mockUser);
		String userJson = "{\"username\": \"davidred\",\"firstName\": \"David\",\"lastName\": \"Red\",\"contactNo\": \"7401213182\",\"email\": \"rdavidr02@gamil.com\",\"city\": \"pune\",\"password\": \"David123\"}";
		
		Mockito.when(userGetterService.searchUser((mockUser))).thenReturn(mockList);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/search")
				.accept(MediaType.APPLICATION_JSON).content(userJson).contentType(MediaType.APPLICATION_JSON);;

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		
		assertEquals(HttpStatus.OK.value(), result.getResponse().getStatus());
	}

}
