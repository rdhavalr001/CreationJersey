/**
 * 
 */
package com.example.creation.dao;

import com.example.creation.model.User;

/**
 * @author dradadiy
 *
 */

public interface UserCreatorDao {
	public boolean createUser(User user);
}
