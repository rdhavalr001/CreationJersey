/**
 * 
 */
package com.example.creation.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.creation.dao.UserCreatorDao;
import com.example.creation.model.User;
import com.example.creation.service.UserCreatorService;

/**
 * @author dradadiy
 *
 */
@Service("UserCreatorServiceImpl")
@Transactional
public class UserCreatorServiceImpl implements UserCreatorService {
	
	@Autowired
	private UserCreatorDao userCreatorDao;
	
	
	@Override
	public boolean createUser(User user) {
		
		return userCreatorDao.createUser(user);
	}


	public UserCreatorDao getUserCreatorDao() {
		return userCreatorDao;
	}


	public void setUserCreatorDao(UserCreatorDao userCreatorDao) {
		this.userCreatorDao = userCreatorDao;
	}
}
