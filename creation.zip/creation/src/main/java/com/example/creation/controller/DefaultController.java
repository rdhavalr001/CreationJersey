package com.example.creation.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
/**
 * @author dradadiy
 *
 */
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.creation.model.User;
import com.example.creation.service.UserCreatorService;
import com.example.creation.service.UserGetterService;

@RestController
@RequestMapping("/")
public class DefaultController {

	@Autowired
	private UserCreatorService userCreatorService;
	
	@Autowired
	private UserGetterService userGetterService;
	
	/*@RequestMapping(value= "/open", method = RequestMethod.GET)
	public String open() {
	 return "How are You?";	
	}*/
	
	@RequestMapping(value= "/submit", method = RequestMethod.POST)
	public ResponseEntity<?> createUser(@RequestBody User user) {
		if(userCreatorService.createUser(user))
		return new ResponseEntity<>(new HttpHeaders(), HttpStatus.CREATED);
		else return new ResponseEntity<>(new HttpHeaders(), HttpStatus.CONFLICT);
	}

	@RequestMapping(value= "/search", method = RequestMethod.POST)
	public ResponseEntity<?> searchUser(@RequestBody User user) {
		
		return new ResponseEntity<>(userGetterService.searchUser(user), new HttpHeaders(), HttpStatus.OK);
	}
	
	@RequestMapping(value= "/get/users", method = RequestMethod.GET)
	public ResponseEntity<?> searchUser() {
		
		return new ResponseEntity<>(userGetterService.getAllUsers(), new HttpHeaders(), HttpStatus.OK);
	}
	
	/*@RequestMapping(value= "/retrieve/username", method = RequestMethod.POST)
	public List<User> getUserWithUsername(@RequestBody User user) {
		System.out.println(user);
		return userGetterService.getUserWithUsername(user);
	}
	
	@RequestMapping(value= "/retrieve/contact", method = RequestMethod.POST)
	public List<User> getUserWithContact(@RequestBody User user) {
		System.out.println(user);
		return userGetterService.getUserWithContact(user);
	}
	
	@RequestMapping(value= "/retrieve/email", method = RequestMethod.POST)
	public List<User> getUserWithEmail(@RequestBody User user) {
		System.out.println(user);
		return userGetterService.getUserWithEmail(user);
	}
	
	@RequestMapping(value= "/retrieve/city", method = RequestMethod.POST)
	public List<User> getUserWithCity(@RequestBody User user){
		System.out.println(user);
		return userGetterService.getUserWithCity(user);
	}
	
	@RequestMapping(value= "/retrieve/firstname", method = RequestMethod.POST)
	public List<User> getUserWithFirstName(@RequestBody User user){
		System.out.println(user);
		return userGetterService.getUserWithFirstName(user);
	}
	
	@RequestMapping(value= "/retrieve/lastname", method = RequestMethod.POST)
	public List<User> getUserWithLastName(User user){
		System.out.println(user);
		return userGetterService.getUserWithLastName(user);
	}*/

	public UserCreatorService getUserCreatorService() {
		
		return userCreatorService;
	}

	public void setUserCreatorService(UserCreatorService userCreatorService) {
		this.userCreatorService = userCreatorService;
	}

	public UserGetterService getUserGetterService() {
		return userGetterService;
	}

	public void setUserGetterService(UserGetterService userGetterService) {
		this.userGetterService = userGetterService;
	}
	
}
