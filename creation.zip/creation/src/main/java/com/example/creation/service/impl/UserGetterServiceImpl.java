/**
 * 
 */
package com.example.creation.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.creation.dao.UserGetterDao;
import com.example.creation.model.User;
import com.example.creation.service.UserGetterService;

/**
 * @author dradadiy
 *
 */
@Service("UserGetterServiceImpl")
public class UserGetterServiceImpl implements UserGetterService {

	@Autowired
	private UserGetterDao userGetterDao; 
	
	@Override
	public List<User> searchUser(User user) {
		if(user != null) {
			if(user.getUsername() != null) return getUserWithUsername(user); 
			if(user.getFirstName() != null) return getUserWithFirstName(user); 
			if(user.getLastName() != null) return getUserWithLastName(user); 
			if(user.getContactNo() != null) return getUserWithContact(user); 
			if(user.getEmail() != null) return getUserWithEmail(user); 
			if(user.getCity() != null) return getUserWithCity(user); 
			else return null;
		}else return null;	
	}
	
	
	@Override
	public List<User> getAllUsers() {
		return userGetterDao.getAllUsers();
	}
	
	@Override
	public List<User> getUserWithUsername(User user) {
		return userGetterDao.getUserWithUsername(user);
	}
	
	@Override
	public List<User> getUserWithContact(User user) {
		return userGetterDao.getUserWithContact(user);
	}
	
	@Override
	public List<User> getUserWithEmail(User user) {
		return userGetterDao.getUserWithEmail(user);
	}

	@Override
	public List<User> getUserWithCity(User user) {
		return userGetterDao.getUserWithCity(user);
	}
	
	@Override
	public List<User> getUserWithFirstName(User user) {
		return userGetterDao.getUserWithFirstName(user);
	}

	@Override
	public List<User> getUserWithLastName(User user) {
		return userGetterDao.getUserWithLastName(user);
	}

	public UserGetterDao getUserGetterDao() {
		return userGetterDao;
	}

	public void setUserGetterDao(UserGetterDao userGetterDao) {
		this.userGetterDao = userGetterDao;
	}

	

	

}
