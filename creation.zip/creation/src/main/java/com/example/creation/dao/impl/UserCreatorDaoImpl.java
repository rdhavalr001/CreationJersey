/**
 * 
 */
package com.example.creation.dao.impl;

import java.util.List;
import java.util.ListIterator;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.creation.dao.UserCreatorDao;
import com.example.creation.dao.UserGetterDao;
import com.example.creation.model.User;

/**
 * @author dradadiy
 *
 */
@Repository("UserCreatorDaoImpl")
public class UserCreatorDaoImpl implements UserCreatorDao {

	
	@PersistenceContext
    private EntityManager entityManager;
	
	private Session getCurrentSession() {
		return entityManager.unwrap(Session.class);
	}
	
	@Autowired
	private UserGetterDao userGetterDao;
	
	@SuppressWarnings("unused")
	@Override
	public boolean createUser(User user1) {
		Session session = getCurrentSession();
		List<User> users= userGetterDao.getAllUsers();
		if(!users.isEmpty()) {
			ListIterator<User> itr = users.listIterator();
			while(itr.hasNext()) {
				User u = itr.next();
				if(u.getUsername()==user1.getUsername()) {
					user1.setId(u.getId());
					session.update(user1);
				}else session.save(user1);
			}
			
		}
		session.save(user1);
		//System.out.println(user1.toString());
		
		return true;
	}

	public UserGetterDao getUserGetterDao() {
		return userGetterDao;
	}

	public void setUserGetterDao(UserGetterDao userGetterDao) {
		this.userGetterDao = userGetterDao;
	}


	

}
