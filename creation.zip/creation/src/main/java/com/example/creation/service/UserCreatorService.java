/**
 * 
 */
package com.example.creation.service;

import com.example.creation.model.User;

/**
 * @author dradadiy
 *
 */
public interface UserCreatorService {
	public boolean createUser(User user);
}
