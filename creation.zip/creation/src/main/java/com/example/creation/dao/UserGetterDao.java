/**
 * 
 */
package com.example.creation.dao;

import java.util.List;

import com.example.creation.model.User;

/**
 * @author dradadiy
 *
 */
public interface UserGetterDao {
	public List<User> getUserWithUsername(User user);
	public List<User> getUserWithContact(User user);
	public List<User> getUserWithEmail(User user);
	public List<User> getUserWithCity(User user);
	public List<User> getUserWithFirstName(User user);
	public List<User> getUserWithLastName(User user);
	public List<User> getAllUsers();

}
