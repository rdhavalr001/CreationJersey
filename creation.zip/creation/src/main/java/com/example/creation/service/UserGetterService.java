/**
 * 
 */
package com.example.creation.service;

import java.util.List;

import com.example.creation.model.User;

/**
 * @author dradadiy
 *
 */
public interface UserGetterService {
	public List<User> getUserWithUsername(User user);
	public List<User> getUserWithContact(User user);
	public List<User> getUserWithEmail(User user);
	public List<User> getUserWithCity(User user);
	public List<User> getUserWithFirstName(User user);
	public List<User> getUserWithLastName(User user);
	public List<User> searchUser(User user);
	public List<User> getAllUsers();
	
}
