/**
 * 
 */
package com.example.creation.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.example.creation.dao.UserGetterDao;
import com.example.creation.model.User;

/**
 * @author dradadiy
 *
 */
@Repository("userGetterDaoImpl")
public class UserGetterDaoImpl implements UserGetterDao {

	@PersistenceContext
    private EntityManager entityManager;
	
	private Session getCurrentSession() {
		return entityManager.unwrap(Session.class);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<User> getAllUsers() {
		Session session = getCurrentSession();
		Query<User> query = session.createQuery("from User");
		return query.list();
		
	}
	
	@Override
	public List<User> getUserWithUsername(User user) {
		Session session = getCurrentSession();
		/*CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<User> cQuery = builder.createQuery(User.class);
		Root<User> root = cQuery.from(User.class);
		cQuery.select(root).where(builder.equal(root.get("username"), user.getUsername()));
		Query<User> q = session.createQuery(cQuery);
		return q.getResultList().get(0);*/
		
		Query query = session.createQuery("from User where username= :username");
		query.setParameter("username", user.getUsername());
		return query.list();
		
	}

	@Override
	public List<User> getUserWithContact(User user) {
		Session session = getCurrentSession();
		/*CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<User> cQuery = builder.createQuery(User.class);
		Root<User> root = cQuery.from(User.class);
		cQuery.select(root).where(builder.equal(root.get("contactNo"), user.getContactNo()));
		Query<User> q = session.createQuery(cQuery);
		return q.getResultList().get(0);*/
		
		Query query = session.createQuery("from User where contact_no= :contact_no");
		query.setParameter("contact_no", user.getContactNo());
		return query.list();
		 
	}

	@Override
	public List<User> getUserWithEmail(User user) {
		Session session = getCurrentSession();
		/*CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<User> cQuery = builder.createQuery(User.class);
		Root<User> root = cQuery.from(User.class);
		cQuery.select(root).where(builder.equal(root.get("email"), user.getEmail()));;
		Query<User> q = session.createQuery(cQuery);
		return q.getSingleResult();
		*/
		Query query = session.createQuery("from User where email= :email");
		query.setParameter("email", user.getEmail());
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<User> getUserWithCity(User user) {
		//List<Object> users = new ArrayList<>();
		Session session = getCurrentSession();
		/*CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<User> cQuery = builder.createQuery(User.class);
		Root<User> root = cQuery.from(User.class);
		cQuery.select(root).where(builder.equal(root.get("city"), user.getCity()));
		Query<User> q = session.createQuery(cQuery);
		return q.getResultList();*/
		/*@SuppressWarnings({ "deprecation", "rawtypes" })
		Query qry = session.createSQLQuery(q.getQueryString());
		users = qry.list();
		users.forEach(i -> System.out.println(i));
		return qry.list();*/
		Query query = session.createQuery("from User where city= :city");
		query.setParameter("city", user.getCity());
		return query.list();
	}

	@Override
	public List<User> getUserWithFirstName(User user) {
		Session session = getCurrentSession();
		/*CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<User> cQuery = builder.createQuery(User.class);
		Root<User> root = cQuery.from(User.class);
		cQuery.select(root).where(builder.equal(root.get("firstName"), user.getFirstName()));
		Query<User> q = session.createQuery(cQuery);
		return q.getResultList();*/
		Query query = session.createQuery("from User where firstName= :firstName");
		query.setParameter("firstName", user.getFirstName());
		return query.list();
	}

	@Override
	public List<User> getUserWithLastName(User user) {
		Session session = getCurrentSession();
		/*CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<User> cQuery = builder.createQuery(User.class);
		Root<User> root = cQuery.from(User.class);
		cQuery.select(root).where(builder.equal(root.get("lastName"), user.getLastName()));
		Query<User> q = session.createQuery(cQuery);
		return q.getResultList();*/
		Query query = session.createQuery("from User where lastName= :lastName");
		query.setParameter("lastName", user.getLastName());
		return query.list();
	}
	

}
